﻿using System.Collections.Generic;

namespace InstagramApiSharp.Classes.Models
{
    public class InstaLocationShortList : List<InstaLocationShort>
    {
    }
}