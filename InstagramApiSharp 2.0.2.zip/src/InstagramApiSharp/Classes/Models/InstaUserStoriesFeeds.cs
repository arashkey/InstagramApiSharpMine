﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InstagramApiSharp.Classes.Models
{
    public class InstaUserStoriesFeeds
    {
        public List<InstaReelFeed> Items = new List<InstaReelFeed>();
    }

}
