﻿namespace InstagramApiSharp.Classes.Models
{
    public class InstaStoryMedia
    {
        public InstaStoryItem Media { get; set; }
    }
}