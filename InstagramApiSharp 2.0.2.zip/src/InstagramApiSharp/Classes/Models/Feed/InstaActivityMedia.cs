﻿namespace InstagramApiSharp.Classes.Models
{
    public class InstaActivityMedia
    {
        public string Id { get; set; }
        public string Image { get; set; }
    }
}
