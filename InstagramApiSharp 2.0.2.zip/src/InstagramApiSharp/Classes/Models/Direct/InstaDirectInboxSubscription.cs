﻿namespace InstagramApiSharp.Classes.Models
{
    public class InstaDirectInboxSubscription
    {
        public string Topic { get; set; }

        public string Url { get; set; }

        public string Auth { get; set; }

        public string Sequence { get; set; }
    }
}