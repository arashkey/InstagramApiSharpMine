﻿namespace InstagramApiSharp.Classes.Models
{
    public class InstaPlaceholder
    {
        public bool IsLinked { get; set; }
        public string Message { get; set; }
        public string Title { get; set; }
    }
}
