﻿namespace InstagramApiSharp.Classes.Models
{
    public class Images
    {
        public InstaImage LowResolution { get; set; }

        public InstaImage Thumbnail { get; set; }

        public InstaImage StandartResolution { get; set; }
    }
}