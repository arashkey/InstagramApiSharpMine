﻿namespace InstagramApiSharp.Classes.Models
{
    public class InstaLikes
    {
        public int Count { get; set; }
        public InstaUserList VisibleLikedUsers { get; set; }
    }
}