﻿using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace InstagramApiSharp.Classes.Models
{
    public class InstaCarousel : List<InstaCarouselItem>
    {
    }
}