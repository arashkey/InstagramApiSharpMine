﻿namespace InstagramApiSharp.Classes.Models
{
    public class InstaLink
    {
        public string Type { get; set; }
        public string Start { get; set; }
        public string End { get; set; }
        public string Id { get; set; }
    }
}