﻿namespace InstagramApiSharp.Classes.Models
{
    public class Dimensions
    {
        public int Width { get; set; }

        public int Height { get; set; }
    }
}