using System.Collections.Generic;

namespace InstagramApiSharp.Classes.ResponseWrappers
{
    public class InstaCarouselResponse : List<InstaCarouselItemResponse>
    {
    }
}