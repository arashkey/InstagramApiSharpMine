﻿using System.Collections.Generic;

namespace InstagramApiSharp.Classes.Models
{
    public class InstaUserList : List<InstaUser>
    {
    }
}