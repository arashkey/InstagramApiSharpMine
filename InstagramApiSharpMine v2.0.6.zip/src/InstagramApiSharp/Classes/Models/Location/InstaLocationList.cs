﻿using System.Collections.Generic;

namespace InstagramApiSharp.Classes.Models
{
    public class InstaLocationList : List<InstaLocation>
    {
    }
}