﻿using System.Collections.Generic;

namespace InstagramApiSharp.Classes.Models
{
    public class InstaDirectInboxThreadList : List<InstaDirectInboxThread>
    {
    }
}