﻿namespace InstagramApiSharp.Classes.Models
{
    public class InstaActionLog
    {
        public string Description { get; set; }
    }
}
