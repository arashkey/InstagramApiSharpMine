﻿namespace InstagramApiSharp.Classes.Models
{
    public class InstaLikersList : InstaUserShortList
    {
        public int UsersCount { get; internal set; }
    }
}