﻿namespace InstagramApiSharp.Classes.Models
{
    public class InstaLink
    {
        public Enums.InstaLinkType Type { get; set; }
        public int Start { get; set; }
        public int End { get; set; }
        public string Id { get; set; }
    }
}