﻿namespace InstagramApiSharp.Classes.Models
{
    public interface IInstaBaseList
    {
        string NextMaxId { get; set; }
    }
}