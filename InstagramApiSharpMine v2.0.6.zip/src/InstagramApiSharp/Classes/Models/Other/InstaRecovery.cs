﻿namespace InstagramApiSharp.Classes.Models
{
    public class InstaRecovery
    {
        public bool PhoneNumberValid { get; set; }
        public string Title { get; set; }
        public string Body { get; set; }
    }
}
